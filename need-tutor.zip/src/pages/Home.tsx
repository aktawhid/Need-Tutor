import { motion } from 'motion/react';
import { Button } from '../components/ui/Button';
import { GraduationCap, Users, ShieldCheck, MapPin, Search, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white pb-16 pt-24 sm:pb-24 sm:pt-32">
        <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80">
          <div
            className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-red-200 to-red-600 opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
            }}
          />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex flex-col items-center"
            >
              <h1 className="text-6xl font-black tracking-tighter text-slate-900 sm:text-8xl lg:text-9xl uppercase text-center">
                Need<br />
                <span className="text-red-600">Tutor</span>
              </h1>
              <p className="mt-8 text-xl font-bold uppercase tracking-widest text-slate-500 max-w-xl mx-auto leading-relaxed">
                চট্টগ্রামের নির্ভরযোগ্য টিউটর প্ল্যাটফর্ম
              </p>
              <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-6">
                <Link to="/parent/post">
                  <Button size="lg" className="w-full sm:w-auto">
                    শিক্ষক খুঁজুন <ChevronRight className="ml-2 h-6 w-6" />
                  </Button>
                </Link>
                <Link to="/tutor/register">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto">
                    টিউটর হন
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-slate-900 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-y-16 sm:grid-cols-3 sm:gap-x-12">
            <div className="flex flex-col items-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-red-500 mb-2">নিবন্ধিত টিউটর</p>
              <h3 className="text-6xl font-black text-white tracking-tighter">৫০০০+</h3>
            </div>
            <div className="flex flex-col items-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-red-500 mb-2">সফল টিউটর ম্যাচ</p>
              <h3 className="text-6xl font-black text-white tracking-tighter">১০০০+</h3>
            </div>
            <div className="flex flex-col items-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-red-500 mb-2">ভেরিফাইড প্রোফাইল</p>
              <h3 className="text-6xl font-black text-white tracking-tighter">১০০%</h3>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-32 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-20">
            <h2 className="text-[10px] font-black leading-7 text-red-600 uppercase tracking-widest mb-4">সেবাসমূহ</h2>
            <p className="text-5xl font-black tracking-tight text-slate-900 sm:text-6xl max-w-2xl">
              কেন আপনি Need Tutor বেছে নিবেন?
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="space-y-6">
              <div className="h-16 w-16 flex items-center justify-center rounded-2xl bg-red-50 text-red-600 font-black text-2xl">01</div>
              <h3 className="text-3xl font-black tracking-tight">এলাকাভিত্তিক সার্চ</h3>
              <p className="text-slate-500 font-medium leading-relaxed">চট্টগ্রামের চকবাজার, জিইসি, আগ্রাবাদসহ সকল এলাকায় টিউটর বা টিউশন খুঁজুন খুব সহজে।</p>
            </div>
            <div className="space-y-6">
              <div className="h-16 w-16 flex items-center justify-center rounded-2xl bg-red-50 text-red-600 font-black text-2xl">02</div>
              <h3 className="text-3xl font-black tracking-tight">নিরাপত্তা ও বিশ্বাসযোগ্যতা</h3>
              <p className="text-slate-500 font-medium leading-relaxed">শিক্ষার্থীদের আইডি কার্ড এবং সামাজিক মাধ্যম যাচাইয়ের মাধ্যমে আমরা নিরাপত্তা নিশ্চিত করি।</p>
            </div>
            <div className="space-y-6">
              <div className="h-16 w-16 flex items-center justify-center rounded-2xl bg-red-50 text-red-600 font-black text-2xl">03</div>
              <h3 className="text-3xl font-black tracking-tight">সেরা শিক্ষাপ্রতিষ্ঠান</h3>
              <p className="text-slate-500 font-medium leading-relaxed">চবি, চুয়েট এবং চট্টগ্রাম কলেজের সেরা মেধাবী শিক্ষার্থীদের মাধ্যমে পড়ানোর সুযোগ।</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
