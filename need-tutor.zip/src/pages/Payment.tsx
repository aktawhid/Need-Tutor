import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { BKASH_NUMBER } from '../constants';
import { CreditCard, CheckCircle, Info } from 'lucide-react';

export function Payment() {
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-6" />
        <h1 className="text-3xl font-bold text-gray-900 mb-4">পেমেন্ট সাবমিট হয়েছে!</h1>
        <p className="text-gray-600 mb-8">
          আপনার ট্রানজেকশন আইডি যাচাইয়ের জন্য পাঠানো হয়েছে। যাচাই শেষে আমরা আপনাকে নোটিফিকেশন পাঠাবো।
        </p>
        <Button onClick={() => window.location.href = '/'}>হোমে ফিরে যান</Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-gray-900">ফি পেমেন্ট করুন</h1>
        <p className="mt-2 text-gray-600">টিউশন কনফার্ম হওয়ার পর ৫০% ফি জমা দিন।</p>
      </div>

      <Card className="shadow-lg">
        <div className="space-y-8">
          <div className="rounded-xl bg-orange-50 p-6 border border-orange-100">
            <h3 className="text-lg font-bold text-orange-800 mb-4 flex items-center gap-2">
              <CreditCard className="h-5 w-5" /> বিকাশ পেমেন্ট ইন্সট্রাকশন
            </h3>
            <ol className="space-y-3 text-sm text-orange-700">
              <li className="flex gap-2">
                <span className="font-bold">১.</span> 
                <span>নিচের নাম্বারে <b>বিকাশ পার্সোনাল</b> থেকে সেন্ড মানি (Send Money) করুন।</span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold text-lg">বিকাশ নাম্বারঃ {BKASH_NUMBER}</span>
              </li>
              <li className="flex gap-2 text-xs">
                <Info className="h-4 w-4 shrink-0" />
                <span>টাকা পাঠানোর পর ট্রানজেকশন আইডি (TrxID) টি কপি করে নিচের ফর্মে জমা দিন।</span>
              </li>
            </ol>
          </div>

          <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}>
            <Input label="টিউশন আইডি (প্রয়োজনীয়)" placeholder="উদাঃ #T1234" required />
            <Input label="টাকার পরিমাণ" placeholder="উদাঃ ২৫০০" type="number" required />
            <Input label="বিকাশ ট্রানজেকশন আইডি (TrxID)" placeholder="উদাঃ 8N7S6D5F4G" required />
            
            <div className="pt-2">
              <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600 h-14 text-white font-bold">
                পেমেন্ট সাবমিট করুন
              </Button>
            </div>
          </form>
        </div>
      </Card>
    </div>
  );
}
