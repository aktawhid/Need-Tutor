import React from 'react';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { CHITTAGONG_ZONES } from '../constants';
import { Search, GraduationCap, MapPin, DollarSign, Calendar, MessageSquare } from 'lucide-react';
import { motion } from 'motion/react';

export function ParentPost() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-12 text-center">
        <h1 className="text-5xl font-black text-slate-900 uppercase tracking-tighter sm:text-6xl">Post a <span className="text-red-600 italic">Job.</span></h1>
        <p className="mt-4 text-[10px] font-black uppercase tracking-widest text-slate-400">সঠিক তথ্য দিয়ে পোস্ট করুন এবং চট্টগ্রামের সেরা শিক্ষকদের সাথে কথা বলুন।</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <form className="space-y-6">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="text-[10px] font-black text-red-600 uppercase tracking-widest ml-1 flex items-center gap-2">
                    <MapPin className="h-4 w-4" /> এলাকা নির্বাচন করুন
                  </label>
                  <select className="mt-2 flex h-14 w-full rounded-xl border border-slate-200 bg-slate-50 px-5 py-2 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-red-600 appearance-none">
                    <option disabled selected>এলাকা বেছে নিন</option>
                    {CHITTAGONG_ZONES.flatMap(z => z.areas).map(area => (
                      <option key={area} value={area}>{area}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <Input 
                    label="শ্রেণী এবং বিষয়" 
                    placeholder="উদাঃ ৯ম শ্রেণী - গণিত, পদার্থবিজ্ঞান" 
                  />
                </div>

                <Input 
                  label="মাসিক বেতন (বাজেট)" 
                  placeholder="উদাঃ ৫০০০" 
                  type="number"
                  prefix={<DollarSign className="h-4 w-4" />}
                />
                
                <div>
                  <label className="text-[10px] font-black text-red-600 uppercase tracking-widest ml-1 flex items-center gap-2">
                    <Calendar className="h-4 w-4" /> সপ্তাহে কয়দিন?
                  </label>
                  <select className="mt-2 flex h-14 w-full rounded-xl border border-slate-200 bg-slate-50 px-5 py-2 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-red-600 appearance-none">
                    {[2, 3, 4, 5, 6].map(d => (
                      <option key={d} value={d}>{d} দিন</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2 space-y-2">
                  <label className="text-[10px] font-black text-red-600 uppercase tracking-widest ml-1 flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> বিস্তারিত তথ্য
                  </label>
                  <textarea
                    rows={4}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-5 py-4 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-red-600 placeholder:text-slate-400"
                    placeholder="টিচার সম্পর্কে বাড়তি কোনো চাহিদা থাকলে লিখুন..."
                  />
                </div>
              </div>

              <Button size="lg" className="w-full">
                পোস্ট সাবমিট করুন
              </Button>
            </form>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-red-600 text-white border-0 shadow-xl shadow-red-200/50">
            <div className="flex items-center gap-3 mb-6">
              <Search className="h-6 w-6" />
              <h3 className="text-xl font-black uppercase tracking-tight">কিভাবে কাজ করে?</h3>
            </div>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-[10px] font-black">01</span>
                <p className="text-sm font-bold opacity-90 leading-snug">আপনি আপনার টিউশন পোস্ট করবেন।</p>
              </li>
              <li className="flex gap-4">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-[10px] font-black">02</span>
                <p className="text-sm font-bold opacity-90 leading-snug">আমরা আপনার এলাকার সেরা এবং দক্ষ টিউটরদের আবেদন পৌঁছে দেব।</p>
              </li>
              <li className="flex gap-4">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-[10px] font-black">03</span>
                <p className="text-sm font-bold opacity-90 leading-snug">টিউটর পছন্দ হলে তাকে নিয়োগ দেবেন।</p>
              </li>
            </ul>
          </Card>

          <Card className="bg-orange-50 border-orange-100">
            <h3 className="text-lg font-bold text-orange-800 mb-2">জরুরী প্রয়োজনে</h3>
            <p className="text-sm text-orange-700 mb-4">আপনার যদি দ্রুত শিক্ষক প্রয়োজন হয় তবে সরাসরি কল করুন আমাদের হটলাইনে।</p>
            <Button variant="secondary" className="w-full">
              হটলাইনঃ ০১৯২৩৬১৪২৯৪
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
