import React from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { CheckCircle, XCircle, Clock, DollarSign, Users, BookOpen } from 'lucide-react';
import { formatCurrency } from '../lib/utils';

export function AdminDashboard() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-gray-900">অ্যাডমিন প্যানেল</h1>
        <p className="text-gray-600">সবকিছু এক জায়গা থেকে নিয়ন্ত্রণ করুন।</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        <Card className="bg-blue-600 text-white border-0">
          <div className="flex items-center gap-4">
            <Users className="h-8 w-8 text-blue-200" />
            <div>
              <p className="text-sm opacity-80">মোট টিউটর</p>
              <p className="text-2xl font-bold">১২৪</p>
            </div>
          </div>
        </Card>
        <Card className="bg-orange-500 text-white border-0">
          <div className="flex items-center gap-4">
            <DollarSign className="h-8 w-8 text-orange-200" />
            <div>
              <p className="text-sm opacity-80">পেন্ডিং পেমেন্ট</p>
              <p className="text-2xl font-bold">০৮</p>
            </div>
          </div>
        </Card>
        <Card className="bg-green-600 text-white border-0">
          <div className="flex items-center gap-4">
            <BookOpen className="h-8 w-8 text-green-200" />
            <div>
              <p className="text-sm opacity-80">একটিভ টিউশন</p>
              <p className="text-2xl font-bold">৪৫</p>
            </div>
          </div>
        </Card>
        <Card className="bg-purple-600 text-white border-0">
          <div className="flex items-center gap-4">
            <Clock className="h-8 w-8 text-purple-200" />
            <div>
              <p className="text-sm opacity-80">নতুন রেজিস্ট্রেশন</p>
              <p className="text-2xl font-bold">১২</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Payments */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-orange-500" /> পেমেন্ট ভেরিফিকেশন
          </h2>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                <div>
                  <p className="font-bold text-gray-900">TrxID: 8N7S6D5F4G</p>
                  <p className="text-xs text-gray-500">Tutor: Asraful Kader • {formatCurrency(2500)}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" className="text-red-600 hover:bg-red-50">রিজেক্ট</Button>
                  <Button size="sm" className="bg-green-600 hover:bg-green-700">এপ্রুভ</Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Tutor Registration */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-500" /> টিউটর ভেরিফিকেশন
          </h2>
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                <div className="flex gap-3 items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                    <Users className="h-5 w-5 text-gray-400" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">মোঃ আরিফ উদ্দিন</p>
                    <p className="text-xs text-gray-500">CUET • 01712......</p>
                  </div>
                </div>
                <Button size="sm" variant="outline">ভিউ প্রোফাইল</Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
