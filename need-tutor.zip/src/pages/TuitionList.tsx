import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { CHITTAGONG_ZONES } from '../constants';
import { MapPin, BookOpen, Calendar, DollarSign, Search, Filter } from 'lucide-react';
import { motion } from 'motion/react';
import { formatCurrency } from '../lib/utils';

const MOCK_TUITIONS = [
  {
    id: '1',
    area: 'চকবাজার',
    class: 'Class 9',
    subjects: ['Math', 'Physics'],
    budget: 5000,
    daysPerWeek: 3,
    createdAt: Date.now() - 86400000,
  },
  {
    id: '2',
    area: 'জিইসি',
    class: 'HSC 1st Year',
    subjects: ['ICT', 'English'],
    budget: 6000,
    daysPerWeek: 4,
    createdAt: Date.now() - 172800000,
  },
  {
    id: '3',
    area: 'আগ্রাবাদ',
    class: 'Class 5',
    subjects: ['All Subjects'],
    budget: 3500,
    daysPerWeek: 5,
    createdAt: Date.now() - 43200000,
  },
];

export function TuitionList() {
  const [selectedArea, setSelectedArea] = useState('All');

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
        <div>
          <h1 className="text-6xl font-black tracking-tighter text-slate-900 uppercase">Available<br /><span className="text-red-600 italic">Jobs.</span></h1>
          <p className="mt-2 text-[10px] font-black uppercase tracking-widest text-slate-400">Showing all premium tuitions in Chittagong</p>
        </div>
        <div className="flex items-center gap-3 pb-1">
          <div className="relative">
            <Filter className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <select 
              className="pl-12 pr-6 h-12 border-slate-200 border rounded-lg bg-white text-xs font-black uppercase tracking-widest focus:ring-2 focus:ring-red-600 outline-none appearance-none"
              onChange={(e) => setSelectedArea(e.target.value)}
            >
              <option value="All">সকল এলাকা</option>
              {CHITTAGONG_ZONES.flatMap(z => z.areas).map(area => (
                <option key={area} value={area}>{area}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_TUITIONS.map((tuition, index) => (
          <motion.div
            key={tuition.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:border-red-600 transition-all cursor-pointer">
              <div className="space-y-6">
                <div className="flex justify-between items-start">
                  <div className="inline-flex items-center gap-1 rounded-full bg-red-50 px-3 py-1 text-[10px] font-black uppercase text-red-600">
                    <MapPin className="h-3 w-3" /> {tuition.area}
                  </div>
                  <span className="text-[10px] font-black uppercase text-slate-400">২ দিন আগে</span>
                </div>
                
                <div>
                  <h3 className="text-3xl font-black tracking-tight text-slate-900 leading-none mb-2">{tuition.class}</h3>
                  <div className="flex flex-wrap gap-2">
                    {tuition.subjects.map(s => (
                      <span key={s} className="text-sm font-bold text-slate-500">{s}</span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 py-6 border-y border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 flex items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                      <DollarSign className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-[9px] uppercase text-slate-400 font-black">বেতন</p>
                      <p className="text-lg font-black tracking-tight">{formatCurrency(tuition.budget)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 flex items-center justify-center rounded-lg bg-red-50 text-red-600">
                      <Calendar className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-[9px] uppercase text-slate-400 font-black">সপ্তাহে</p>
                      <p className="text-lg font-black tracking-tight">{tuition.daysPerWeek} দিন</p>
                    </div>
                  </div>
                </div>

                <Button className="w-full" size="md">
                  আবেদন করুন
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
