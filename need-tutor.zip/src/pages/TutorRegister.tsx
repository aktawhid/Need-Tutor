import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { CHITTAGONG_ZONES } from '../constants';
import { Shield, BookOpen, MapPin, GraduationCap, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function TutorRegister() {
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  const nextStep = () => setStep((s) => Math.min(s + 1, totalSteps));
  const prevStep = () => setStep((s) => Math.max(s - 1, 1));

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-12 text-center">
        <h1 className="text-5xl font-black text-slate-900 uppercase tracking-tighter sm:text-6xl">Tutor <span className="text-red-600 italic">Sign up.</span></h1>
        <p className="mt-4 text-[10px] font-black uppercase tracking-widest text-slate-400">খুব সহজেই আপনার প্রোফাইল তৈরি করুন এবং চট্টগ্রামের সেরা টিউশন খুঁজে নিন।</p>
      </div>

      {/* Progress Steps */}
      <div className="mb-10 flex items-center justify-between">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="flex flex-1 items-center last:flex-none">
            <div
              className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 font-black transition-all text-xs ${
                step >= i ? 'border-red-600 bg-red-600 text-white' : 'border-slate-200 bg-white text-slate-400'
              }`}
            >
              {step > i ? '✓' : i}
            </div>
            {i < 4 && (
              <div
                className={`h-0.5 w-full mx-2 rounded-full transition-all ${
                  step > i ? 'bg-red-600' : 'bg-slate-200'
                }`}
              />
            )}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="shadow-xl">
            {step === 1 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-red-600">
                  <GraduationCap className="h-6 w-6" />
                  <h2 className="text-xl font-black uppercase tracking-tight">প্রাথমিক তথ্য</h2>
                </div>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <Input label="আপনার নাম" placeholder="নাম লিখুন" />
                  <Input label="ফোন নাম্বার" placeholder="০১৯২৩......" type="tel" />
                  <div className="sm:col-span-2">
                    <Input label="শিক্ষা প্রতিষ্ঠান" placeholder="চবি / চুয়েট / চট্টগ্রাম কলেজ" />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-red-600 uppercase tracking-widest ml-1">লিঙ্গ</label>
                    <select className="mt-1.5 flex h-14 w-full rounded-xl border border-slate-200 bg-slate-50 px-5 py-2 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-red-600 appearance-none">
                      <option>পুরুষ</option>
                      <option>মহিলা</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-red-600">
                  <Shield className="h-6 w-6" />
                  <h2 className="text-xl font-black uppercase tracking-tight">নিরাপত্তা ও ভেরিফিকেশন</h2>
                </div>
                <div className="space-y-4">
                  <label className="block text-[10px] font-black text-red-600 uppercase tracking-widest ml-1">স্টুডেন্ট আইডি কার্ড আপলোড</label>
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-slate-200 border-dashed rounded-3xl cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Shield className="w-10 h-10 mb-3 text-slate-300" />
                        <p className="mb-2 text-[10px] text-slate-500 font-black uppercase tracking-widest">ক্লিক করে ছবি আপলোড করুন</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">PDF, PNG, JPG (Max 5MB)</p>
                      </div>
                      <input type="file" className="hidden" />
                    </label>
                  </div>
                  <Input label="ফেসবুক প্রোফাইল লিংক (ঐচ্ছিক)" placeholder="https://facebook.com/yourprofile" />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-red-600">
                  <MapPin className="h-6 w-6" />
                  <h2 className="text-xl font-black uppercase tracking-tight">এলাকা নির্বাচন</h2>
                </div>
                <div className="grid grid-cols-1 gap-8 sm:grid-cols-2">
                  {CHITTAGONG_ZONES.map((zone) => (
                    <div key={zone.id} className="space-y-3">
                      <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{zone.name}</h3>
                      <div className="flex flex-wrap gap-2">
                        {zone.areas.map((area) => (
                          <button
                            key={area}
                            className="px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg bg-slate-100 text-slate-500 hover:bg-red-50 hover:text-red-600 transition-colors"
                          >
                            {area}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 text-red-600">
                  <BookOpen className="h-6 w-6" />
                  <h2 className="text-xl font-black uppercase tracking-tight">বিস্তারিত বর্ণনা</h2>
                </div>
                <div className="space-y-4">
                  <label className="block text-[10px] font-black text-red-600 uppercase tracking-widest ml-1">নিজের অভিজ্ঞতা ও পড়ানোর বিশেষত্ব</label>
                  <textarea
                    rows={6}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-5 py-4 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-red-600 placeholder:text-slate-400"
                    placeholder="আপনার অভিজ্ঞতা এবং পড়ানোর মাধ্যম সম্পর্কে লিখুন..."
                  />
                </div>
                <div className="rounded-2xl bg-red-50 p-6 border border-red-100">
                  <div className="flex gap-4">
                    <CheckCircle className="h-6 w-6 text-red-600 shrink-0" />
                    <p className="text-xs font-bold text-red-700 leading-relaxed uppercase tracking-tight">
                      আপনার তথ্য যাচাইয়ের পর ৪৮ ঘণ্টার মধ্যে প্রোফাইলটি এপ্রুভ করা হবে।
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-10 flex justify-between">
              <Button
                variant="ghost"
                onClick={prevStep}
                className={step === 1 ? 'invisible' : ''}
              >
                <ArrowLeft className="mr-2 h-4 w-4" /> ফিরে যান
              </Button>
              <Button onClick={step === totalSteps ? undefined : nextStep}>
                {step === totalSteps ? 'সাবমিট করুন' : 'পরবর্তী ধাপ'} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
