/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { TutorRegister } from './pages/TutorRegister';
import { ParentPost } from './pages/ParentPost';
import { Payment } from './pages/Payment';
import { TuitionList } from './pages/TuitionList';
import { AdminDashboard } from './pages/AdminDashboard';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { FloatingSupport } from './components/FloatingSupport';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#FDFDFD] text-gray-900 font-sans flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tutor/register" element={<TutorRegister />} />
            <Route path="/parent/post" element={<ParentPost />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/tuitions" element={<TuitionList />} />
            <Route path="/admin" element={<AdminDashboard />} />
          </Routes>
        </main>
        <Footer />
        <FloatingSupport />
      </div>
    </Router>
  );
}
