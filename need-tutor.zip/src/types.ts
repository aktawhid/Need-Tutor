export enum UserRole {
  TUTOR = 'tutor',
  PARENT = 'parent',
  ADMIN = 'admin',
}

export interface Zone {
  id: string;
  name: string;
  areas: string[];
}

export interface TutorProfile {
  uid: string;
  name: string;
  phone: string;
  institution: string;
  idCardUrl: string;
  profilePicUrl?: string;
  facebookUrl?: string;
  areas: string[]; // List of areas they can teach in
  description: string;
  status: 'pending' | 'verified' | 'rejected';
  gender: 'male' | 'female';
  createdAt: number;
}

export interface TuitionPost {
  id: string;
  parentId: string;
  area: string;
  zoneId: string;
  class: string;
  subjects: string[];
  budget: number;
  daysPerWeek: number;
  details: string;
  status: 'active' | 'assigned' | 'completed' | 'cancelled';
  assignedTutorId?: string;
  createdAt: number;
}

export interface PaymentRecord {
  id: string;
  tutorId: string;
  tuitionId: string;
  amount: number;
  trxId: string;
  status: 'pending' | 'verified' | 'rejected';
  createdAt: number;
}

export interface RefundRequest {
  id: string;
  paymentId: string;
  tutorId: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
}
