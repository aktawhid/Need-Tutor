import { GraduationCap, Phone, Facebook, Instagram, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SUPPORT_PHONE, BKASH_NUMBER } from '../constants';

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="mx-auto max-w-7xl px-8 py-20">
        <div className="grid grid-cols-1 gap-16 md:grid-cols-4">
          <div className="space-y-6">
            <div className="flex flex-col">
              <span className="text-4xl font-black tracking-tighter text-red-600 uppercase leading-none">
                Need<br />Tutor
              </span>
              <p className="mt-4 text-[10px] font-black uppercase tracking-widest text-slate-500">চট্টগ্রামের নির্ভরযোগ্য টিউটর প্ল্যাটফর্ম</p>
            </div>
          </div>

          <div>
            <h3 className="text-[10px] font-black uppercase tracking-widest text-white mb-6">লিংকসমূহ</h3>
            <ul className="space-y-3">
              <li><Link to="/tutor/register" className="text-sm font-bold hover:text-red-600 transition-colors">টিউটর রেজিস্ট্রেশন</Link></li>
              <li><Link to="/parent/post" className="text-sm font-bold hover:text-red-600 transition-colors">টিউশন পোস্ট করুন</Link></li>
              <li><Link to="/tuitions" className="text-sm font-bold hover:text-red-600 transition-colors">এভেইলএবল টিউশন</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-[10px] font-black uppercase tracking-widest text-white mb-6">যোগাযোগ</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-red-600" />
                <span className="text-sm font-bold uppercase">{SUPPORT_PHONE}</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-red-600" />
                <span className="text-sm font-bold uppercase">support@needtutor.com</span>
              </li>
              <li className="flex items-center gap-3">
                <div className="rounded bg-orange-600/10 px-2 py-0.5 text-[10px] font-black text-orange-600 uppercase tracking-widest border border-orange-600/20">bKash</div>
                <span className="text-sm font-bold uppercase">{BKASH_NUMBER}</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-[10px] font-black uppercase tracking-widest text-white mb-6">সোশ্যাল মিডিয়া</h3>
            <div className="flex gap-4">
              <a href="#" className="h-12 w-12 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-red-600 transition-all">
                <Facebook className="h-5 w-5 text-white" />
              </a>
              <a href="#" className="h-12 w-12 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-orange-600 transition-all">
                <Instagram className="h-5 w-5 text-white" />
              </a>
            </div>
          </div>
        </div>
        <div className="mt-20 border-t border-slate-800 pt-10 text-center">
          <p className="text-[10px] font-black tracking-widest text-slate-500 uppercase">
            &copy; {new Date().getFullYear()} Need Tutor CTG • Security Encrypted • Managed by Chittagong Tuition Media
          </p>
        </div>
      </div>
    </footer>
  );
}
