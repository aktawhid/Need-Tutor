import { Link } from 'react-router-dom';
import { Home, Phone } from 'lucide-react';
import { Button } from './ui/Button';
import { SUPPORT_PHONE } from '../constants';

export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white">
      <div className="mx-auto flex h-24 max-w-7xl items-center justify-between px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-600 text-white">
            <Home className="h-7 w-7" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-3xl font-black tracking-tighter text-red-600 uppercase">
              Need<br />Tutor
            </span>
          </div>
        </Link>
        <div className="hidden md:flex md:items-center md:gap-10">
          <Link to="/tutor/register" className="text-xs font-black uppercase tracking-widest text-slate-500 hover:text-red-600 transition-colors">
            টিউটর রেজিস্ট্রেশন
          </Link>
          <Link to="/parent/post" className="text-xs font-black uppercase tracking-widest text-slate-500 hover:text-red-600 transition-colors">
            টিউশন খুঁজুন
          </Link>
          <Link to="/tuitions" className="text-xs font-black uppercase tracking-widest text-slate-500 hover:text-red-600 transition-colors">
            এভেইলএবল টিউশন
          </Link>
          <a
            href={`tel:${SUPPORT_PHONE}`}
            className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-red-600 transition-colors"
          >
            <Phone className="h-3 w-3" />
            {SUPPORT_PHONE}
          </a>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm">
            লগইন
          </Button>
          <Link to="/parent/post">
            <Button size="sm">
              শুরু করুন
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
}
