import { Phone, MessageCircle } from 'lucide-react';
import { SUPPORT_PHONE } from '../constants';
import { motion } from 'motion/react';

export function FloatingSupport() {
  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col gap-3">
      <motion.a
        href={`https://wa.me/${SUPPORT_PHONE}`}
        target="_blank"
        rel="noreferrer"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-green-500 text-white shadow-lg hover:bg-green-600 transition-colors"
      >
        <MessageCircle className="h-7 w-7" />
      </motion.a>
      <motion.a
        href={`tel:${SUPPORT_PHONE}`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg hover:bg-blue-700 transition-colors"
      >
        <Phone className="h-7 w-7" />
      </motion.a>
    </div>
  );
}
