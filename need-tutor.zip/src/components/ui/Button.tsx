import React from 'react';
import { cn } from '../../lib/utils';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', isLoading, children, ...props }, ref) => {
    const variants = {
      primary: 'bg-red-600 text-white hover:bg-red-700 shadow-sm active:scale-95',
      secondary: 'bg-orange-500 text-white hover:bg-orange-600 shadow-sm active:scale-95',
      outline: 'border-2 border-red-600 text-red-600 hover:bg-red-50 active:scale-95',
      ghost: 'text-slate-600 hover:bg-slate-100 active:scale-95',
    };

    const sizes = {
      sm: 'px-4 py-2 text-xs font-black uppercase tracking-widest',
      md: 'px-8 py-3 font-bold',
      lg: 'px-10 py-5 text-xl font-black uppercase tracking-tight',
    };

    return (
      <button
        ref={ref}
        className={cn(
          'inline-flex items-center justify-center rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed',
          variants[variant],
          sizes[size],
          className
        )}
        disabled={isLoading}
        {...props}
      >
        {isLoading ? (
          <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
        ) : null}
        {children}
      </button>
    );
  }
);
