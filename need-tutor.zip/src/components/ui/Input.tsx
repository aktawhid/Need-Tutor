import { cn } from '../../lib/utils';
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className, ...props }, ref) => {
    return (
      <div className="w-full space-y-2">
        {label && (
          <label className="text-[10px] font-black text-red-600 uppercase tracking-widest ml-1">
            {label}
          </label>
        ) }
        <input
          ref={ref}
          className={cn(
            'flex h-14 w-full rounded-xl border border-slate-200 bg-slate-50 px-5 py-2 text-sm font-bold ring-offset-white transition-all placeholder:text-slate-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-600 disabled:cursor-not-allowed disabled:opacity-50',
            error && 'border-red-500 focus-visible:ring-red-500',
            className
          )}
          {...props}
        />
        {error && <p className="text-[10px] font-black text-red-500 uppercase tracking-widest ml-1">{error}</p>}
      </div>
    );
  }
);
