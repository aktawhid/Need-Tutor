import React from 'react';
import { cn } from '../../lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  description?: string;
}

export function Card({ title, description, children, className, ...props }: CardProps) {
  return (
    <div className={cn('overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm', className)} {...props}>
      {(title || description) && (
        <div className="border-b border-slate-100 p-8">
          {title && <h3 className="text-2xl font-black tracking-tight text-slate-900">{title}</h3>}
          {description && <p className="mt-1 text-[10px] font-black uppercase tracking-widest text-slate-400">{description}</p>}
        </div>
      )}
      <div className="p-8">{children}</div>
    </div>
  );
}
